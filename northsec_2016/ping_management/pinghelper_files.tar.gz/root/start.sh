#!/bin/bash

source /etc/profile.d/rvm.sh


cd /root/pinghelper

rails s -e production -p 3003 -b ::
